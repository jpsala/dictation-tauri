# AOS/OMP separation snapshot

- Repo: `C:/dev/dictation-tauri`
- Snapshot: `2026-08-07T16:45:24Z`

## Files

| Repo | Origin relative | Snapshot | SHA-256 |
| --- | --- | --- | --- |
| `C:/dev/dictation-tauri` | `AGENTS.md` | `2026-08-07T16:45:24Z` | `f9e14f2528d63f486ff9d9b1db9b14f6aacded3f028330693dea5bd02ba43eb2` |
| `C:/dev/dictation-tauri` | `docs/ASSISTANT_RULES.md` | `2026-08-07T16:45:24Z` | `7d6efae8f603cd1bfbff05a334ec5e9acb88a516179dafe181e3e7c03b1c6a7f` |
| `C:/dev/dictation-tauri` | `docs/DECISIONS.md` | `2026-08-07T16:45:24Z` | `f06897c3708e83b5afeb6263cfa9e9161db14adb9415f63c286831900559cb37` |
| `C:/dev/dictation-tauri` | `docs/TOPICS.md` | `2026-08-07T16:45:24Z` | `af65c1eb1f4c2da7d12bbfb57bae15925629c36e59c6a897da31dd74fdd34d6d` |
| `C:/dev/dictation-tauri` | `docs/reference/tool-routing.yaml` | `2026-08-07T16:45:24Z` | `6cfd5e8be498dc665e87d5ba2c2963cdb1f74109655d9b0c816964906642a670` |
| `C:/dev/dictation-tauri` | `docs/skills/README.md` | `2026-08-07T16:45:24Z` | `5cf378ebee5b5c887209a446eca7ace0abe0d13407ebbcef7b4327636ea27f04` |
| `C:/dev/dictation-tauri` | `docs/topics/agent-tool-routing.md` | `2026-08-07T16:45:24Z` | `8e257f628d290e9e3f60d90bcbedb09d5c2bdb17d00716fe512d31158de0b5cd` |
| `C:/dev/dictation-tauri` | `docs/topics/agentic-os.md` | `2026-08-07T16:45:24Z` | `1ecbdbb9ef62ac01c00c8ee3c0702906f54d829b2e940e1c229265d6de2fcc69` |
| `C:/dev/dictation-tauri` | `docs/topics/agentic-os-operations.md` | `2026-08-07T16:45:24Z` | `6a969ede91bef87b39d350f0e003c70b4cc0ad1720b0b2c43728f036e5be7601` |
| `C:/dev/dictation-tauri` | `docs/topics/docs-knowledge-system.md` | `2026-08-07T16:45:24Z` | `28cfe313ec4553b557dc5047056cdea938538923f2abefadf68a40bd0552c4b3` |
| `C:/dev/dictation-tauri` | `docs/topics/local-codex-skills.md` | `2026-08-07T16:45:24Z` | `9afcbfa30c85e841106dc0497aec371c381d45d760788bd3a7727acd0e5d43b5` |
| `C:/dev/dictation-tauri` | `docs/topics/minimal-implementation.md` | `2026-08-07T16:45:24Z` | `32e23a17c7d0f41b0b817ad27bfdbcb65a69e034d68cf114abb8821eed97ae23` |
| `C:/dev/dictation-tauri` | `docs/topics/os-quality.md` | `2026-08-07T16:45:24Z` | `fdffa585ec776356e45a6347413e97ed180d1aeac03abf5d2763431cfc3dd1c8` |
| `C:/dev/dictation-tauri` | `docs/topics/portable-multiharness-contract.md` | `2026-08-07T16:45:24Z` | `d91b194b998e230c2deeb1ad27ab7261df8ac4e46d9405e8212bc30cf0e9d3da` |
| `C:/dev/dictation-tauri` | `package.json` | `2026-08-07T16:45:24Z` | `246468d06ae87915d6e953d08f305060857358a1c5aa44838b566be28c54da9c` |
| `C:/dev/dictation-tauri` | `scripts/agent-context-audit.ts` | `2026-08-07T16:45:24Z` | `8a7d7a931d0ae58f637bc70c14dc66b07dc2c37b6ebd9362db86dcdf85463100` |
| `C:/dev/dictation-tauri` | `scripts/context-index.ts` | `2026-08-07T16:45:24Z` | `9e701550da284e07b07aee1a92d9e28e57a3ca416b7dd6997494c78a182412f0` |
| `C:/dev/dictation-tauri` | `scripts/traycer-routing-check.ts` | `2026-08-07T16:45:24Z` | `56911a148a123da854d139c2a017b6c62b26688d33060da4ce17a50fd89fa527` |
| `C:/dev/dictation-tauri` | `scripts/traycer-routing-contract.test.ts` | `2026-08-07T16:45:24Z` | `24069574bae86c4971552472517c30ee34fba1f7d8afb4374b3cddab3f2648b2` |
| `C:/dev/dictation-tauri` | `scripts/traycer-routing-contract.ts` | `2026-08-07T16:45:24Z` | `0cd057837d45a2afa652a353609a42296d168733b9015f71f5aafb947744d4e9` |

## Exact restore procedure

Run in PowerShell:

```powershell
$repo = 'C:/dev/dictation-tauri'
$zip = Join-Path $repo 'archive/aos-omp-separation-2026-08-07.zip'
$tmp = Join-Path $env:TEMP 'dictation-tauri-aos-omp-separation-2026-08-07-restore'
Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force
Get-ChildItem -LiteralPath $tmp -File -Recurse | Where-Object { $_.Name -ne 'manifest.md' } | ForEach-Object {
  $relative = $_.FullName.Substring($tmp.Length).TrimStart([char]92, [char]47)
  $destination = Join-Path $repo $relative
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
}
Remove-Item -LiteralPath $tmp -Recurse -Force
```

This restores the exact pre-edit bytes listed above. It does not remove files created after the snapshot.
